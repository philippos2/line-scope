import hashlib,json,os,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone

out=Path(os.environ['H7_OUTPUT']);out.mkdir(mode=0o700,parents=True,exist_ok=False)
manifest={'started':datetime.now(timezone.utc).isoformat(),'model_used':False,'responses':[]}
def send(identifier,base,body,token,status,expect):
 payload=json.dumps(body,ensure_ascii=False).encode();(out/(identifier+'.request.json')).write_bytes(payload)
 request=urllib.request.Request(base+'/agent',data=payload,headers={'Content-Type':'application/json',**({'Authorization':'Bearer '+token} if token else {})})
 try: response=urllib.request.urlopen(request,timeout=60)
 except urllib.error.HTTPError as error:response=error
 with response:raw=response.read();http=response.status
 (out/(identifier+'.response.body')).write_bytes(raw)
 parsed=json.loads(raw);data=parsed.get('data',{});sections=data.get('answer_sections',{})
 row={'id':identifier,'http_status':http,'request_id':parsed.get('request_id'),'sha256':hashlib.sha256(raw).hexdigest(),'pass':http==status,'expected':expect}
 if expect in ('empty','catalog','denied'):
  row['pass'] &= not sections.get('facts') and not data.get('tool_results')
 if expect=='explicit':
  row['pass'] &= bool(sections.get('facts')) and sections.get('read_outcome')=='EXPLICIT_READ'
 if expect=='catalog':row['pass'] &= bool(data.get('read_catalog',{}).get('entries'))
 if expect=='partial':
  row['pass'] &= sections.get('read_outcome')=='INCOMPLETE' and all(f.get('predicate')=='equipment.identity' for f in sections.get('facts',[])) and all(o['tool']=='get_equipment' for o in data.get('tool_results',[]))
 manifest['responses'].append(row);(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False),flush=True)
 if not row['pass']:raise RuntimeError('H7 acceptance failed: '+identifier)
 return parsed
base='http://127.0.0.1:8003';token=os.environ['LINESCOPE_AGENT_TOKEN']
cat=send('A01',base,{'message':'参照項目','read_selection':{'operation':'CATALOG'}},token,200,'catalog')['data']['read_catalog']
version=cat['version']
prior=Path('/repo/.git/verification/pr276/api-verbatim-20261023T122539Z')
def find_id(name,code):
 data=json.loads((prior/name).read_bytes())['data']['tool_results']
 return next(item['equipment_id'] for obs in data if obs['tool']=='search_equipment' for item in obs['data']['items'] if item.get('equipment_code')==code)
first=find_id('Q03-1.response.body','M-204');second=find_id('Q08-1.response.body','M-208')
def body(key,ids=(first,)):
 return {'message':'補助入力をそのまま保持する','read_selection':{'operation':'EXECUTE','catalog_version':version,'key':key,'targets':[{'entity_type':'Equipment','entity_id':value} for value in ids]}}
for identifier,key,ids in [('A02','registered_state',(first,)),('A03','equipment_type',(first,)),('A04','maintenance_records',(first,)),('A05','upstream_dependencies',(first,)),('A06','capacity_input',(second,))]:send(identifier,base,body(key,ids),token,200,'explicit')
invalid=[{'message':'補助入力','read_selection':{'operation':'EXECUTE'}},body('nonexistent'),body('registered_state'),body('registered_state',('invalid-id',)),body('__none__'),{**body('registered_state'),'context_id':first}]
invalid[2]['read_selection']['catalog_version']='retired'
for i,value in enumerate(invalid,7):send(f'A{i:02}',base,value,token,400,'catalog')
fault='http://127.0.0.1:8126';mode_path=Path('/repo/.git/verification/pr276/h7-live/mode.json');owned=json.loads(mode_path.with_name('owned-context.json').read_text())['context_id']
fixture_first='00000000-0000-0000-0000-000000000015'
for identifier,mode,status,expect in [('F01','authentication',401,'denied'),('F02','authorization',403,'denied'),('F03','owner',403,'denied'),('F04','identity',500,'empty'),('F05','evidence',500,'empty'),('F06','unavailable',200,'partial')]:
 mode_path.write_text(json.dumps({'mode':mode}))
 value=body('registered_state',(fixture_first,));credential='owner-token'
 if mode=='authentication':credential=''
 if mode=='owner':value={'message':'元の問い','context_id':owned,'read_confirmation':'ACCEPT'};credential='other-token'
 send(identifier,fault,value,credential,status,expect)
manifest['finished']=datetime.now(timezone.utc).isoformat();manifest['complete']=len(manifest['responses'])==18
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
