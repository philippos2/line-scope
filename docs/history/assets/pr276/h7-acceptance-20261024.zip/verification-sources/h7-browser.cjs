const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
(async()=>{
 const out=process.env.LINESCOPE_BROWSER_OUTPUT;
 fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--disable-gpu']});
 const page=await browser.newPage({viewport:{width:1600,height:1100}});page.setDefaultTimeout(30000);
 const report={cases:[],errors:[],blocked:[],requests:[],model_used:false,verdict:'未確認'};
 let phase='setup';
 page.on('pageerror',e=>report.errors.push(e.message));
 await page.addInitScript(()=>{window.__h7Actions=0;document.addEventListener('click',()=>window.__h7Actions++,true);});
 await page.route('**/api/**',async route=>{
  const req=route.request(),path=new URL(req.url()).pathname;
  if(req.method()==='GET')return route.continue();
  if(['/api/session/login','/api/session/logout','/api/incidents/investigate','/api/decisions/compare','/api/economic-inputs/search','/api/capacity-inputs/search','/api/safety-inputs/search','/api/maintenance-inputs/search'].includes(path))return route.continue();
  let body={};try{body=req.postDataJSON()||{};}catch{}
  if(path==='/api/agent'&&(body.read_selection||['関係分析 ','文書検索：','登録入力で比較 '].some(p=>body.message?.startsWith(p)))){
   report.requests.push({phase,operation:body.read_selection?.operation||'existing_machine_read',key:body.read_selection?.key});return route.continue();
  }
  report.blocked.push({path,method:req.method()});return route.abort();
 });
 const pane=page.getByRole('region',{name:'登録情報を選んで調べる',exact:true});
 const execute=()=>pane.getByRole('button',{name:'この項目を調べる',exact:true});
 async function read(key){await pane.getByLabel('調べる項目',{exact:true}).selectOption(key);const pending=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/agent'&&r.request().postDataJSON()?.read_selection?.operation==='EXECUTE');await execute().click();const response=await pending;assert.equal(response.status(),200);const body=await response.json();assert.equal(body.data.read_selection.key,key);assert.equal(body.data.answer_sections.read_outcome,'EXPLICIT_READ');await pane.getByRole('region',{name:'選択した照会の結果',exact:true}).waitFor();return body;}
 async function done(id,began,actions,extra={}){report.cases.push({id,elapsed_ms:Date.now()-began,clicks:await page.evaluate(()=>window.__h7Actions)-actions,pass:true,...extra});await page.screenshot({path:out+'/'+id+'.png',fullPage:true});fs.writeFileSync(out+'/report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report.cases.at(-1)));}
 try{
  await page.goto(process.env.LINESCOPE_BROWSER_URL);
  await page.getByLabel('Bearer token',{exact:true}).fill(process.env.LINESCOPE_BROWSER_TOKEN);
  await page.getByRole('button',{name:'接続する',exact:true}).click();
  await page.getByRole('button',{name:'設備を選ぶ',exact:true}).click();
  await page.getByLabel('設備名・コード',{exact:true}).fill('M-204');
  await page.getByRole('button',{name:'検索',exact:true}).click();
  await page.getByRole('button',{name:/第1加工機.*M-204/}).click();
  await page.getByRole('tab',{name:'質問する',exact:true}).click();
  phase='B1';let began=Date.now(),actions=await page.evaluate(()=>window.__h7Actions);
  await pane.getByRole('button',{name:'照会項目を取得',exact:true}).click();
  await pane.getByLabel('調べる項目',{exact:true}).selectOption('registered_state');
  await pane.getByRole('button',{name:/画面の設備/}).click();
  let body=await read('registered_state');
  assert.ok(body.data.answer_sections.facts.some(f=>f.predicate==='get_equipment_state'));
  await done(phase,began,actions,{key:'registered_state',facts:body.data.answer_sections.facts.length});
  phase='B2';began=Date.now();actions=await page.evaluate(()=>window.__h7Actions);
  const original='m-208の消耗部品のストックはどの倉庫に保管されているか？';
  await page.getByLabel('関係や影響について質問する',{exact:true}).fill(original);
  await pane.getByLabel('調べる項目',{exact:true}).selectOption('registered_state');
  await pane.getByRole('button',{name:/画面の設備/}).click();body=await read('registered_state');
  assert.equal(body.data.read_selection.original_question,original);
  assert.equal(body.data.read_selection.targets[0].entity_type,'Equipment');
  assert.ok((await pane.innerText()).includes('元の質問への回答ではなく'));
  await done(phase,began,actions,{original,selected:'registered_state'});
  phase='B3';began=Date.now();actions=await page.evaluate(()=>window.__h7Actions);
  const before=report.requests.filter(r=>r.operation==='EXECUTE').length;
  await pane.getByLabel('調べる項目',{exact:true}).selectOption('__none__');
  assert.ok((await pane.innerText()).includes('参照は行いません'));
  assert.equal(report.requests.filter(r=>r.operation==='EXECUTE').length,before);
  await done(phase,began,actions,{executions:0});
  phase='B4';began=Date.now();actions=await page.evaluate(()=>window.__h7Actions);
  await pane.getByLabel('調べる項目',{exact:true}).selectOption('common_dependencies');
  await pane.getByLabel('照会対象の設備名・コード',{exact:true}).fill('M-208');
  await pane.getByRole('button',{name:'照会対象の候補を検索',exact:true}).click();
  await pane.getByRole('button',{name:/第2加工機.*M-208を追加/}).click();
  body=await read('common_dependencies');assert.equal(body.data.read_selection.targets.length,2);
  await done(phase,began,actions,{targets:2});
  phase='B5';began=Date.now();actions=await page.evaluate(()=>window.__h7Actions);
  let injected=false;
  await page.route('**/api/agent',async route=>{if(!injected&&route.request().postDataJSON()?.read_selection?.operation==='EXECUTE'){injected=true;return route.abort('failed');}return route.fallback();});
  await execute().click();await pane.getByRole('alert').waitFor();
  assert.ok(await pane.getByRole('region',{name:'選択した照会の結果',exact:true}).isVisible());
  await pane.getByRole('button',{name:'選択した登録情報を取得を再試行',exact:true}).click();
  await pane.getByRole('alert').waitFor({state:'hidden'});assert.equal(injected,true);
  await done(phase,began,actions,{failure:'browser transport abort (controlled)',retry:'actual API'});
  phase='B6';began=Date.now();actions=await page.evaluate(()=>window.__h7Actions);
  await pane.getByRole('list',{name:'照会対象',exact:true}).getByRole('listitem').filter({hasText:'M-208'}).getByRole('button',{name:'対象から外す',exact:true}).click();
  await pane.getByLabel('調べる項目',{exact:true}).selectOption('registered_comparison');
  await pane.getByRole('button',{name:'選んだ対象で画面を開く',exact:true}).click();
  assert.equal(await page.getByRole('tab',{name:'対応案を比べる',exact:true}).getAttribute('aria-selected'),'true');
  await page.getByRole('tab',{name:'質問する',exact:true}).click();
  await pane.getByLabel('調べる項目',{exact:true}).selectOption('document_excerpt');
  await pane.getByRole('button',{name:'選んだ対象で画面を開く',exact:true}).click();
  assert.equal(await page.getByRole('tab',{name:'出典と経路',exact:true}).getAttribute('aria-selected'),'true');
  const docs=page.getByRole('region',{name:'関連文書の検索',exact:true});assert.ok((await docs.innerText()).includes('M-204'));
  const pending=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/agent'&&r.request().postDataJSON()?.message?.startsWith('文書検索：'));
  await docs.getByRole('button',{name:'選択設備の関連文書を検索',exact:true}).click();assert.equal((await pending).status(),200);
  await done(phase,began,actions,{existing_paths:['search','graph','comparison','documents']});
  assert.equal(report.errors.length,0);assert.equal(report.blocked.length,0);report.verdict='PASS';
 }catch(error){report.verdict='FAIL';report.failure=String(error.stack||error);await page.screenshot({path:out+'/failure.png',fullPage:true}).catch(()=>{});process.exitCode=1;}
 finally{fs.writeFileSync(out+'/report.json',JSON.stringify(report,null,2));await browser.close();console.log(JSON.stringify({verdict:report.verdict,cases:report.cases.length,errors:report.errors,blocked:report.blocked}));}
})();
