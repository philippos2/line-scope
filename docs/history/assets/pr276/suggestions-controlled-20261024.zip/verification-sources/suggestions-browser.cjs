const {chromium}=require('playwright');const assert=require('node:assert/strict');const fs=require('node:fs');
(async()=>{
const out=process.env.LINESCOPE_BROWSER_OUTPUT;fs.mkdirSync(out,{recursive:true});const report={model_used:false,classification:'controlled actual HTTP classifier',cases:[],errors:[],blocked:[]};
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--disable-gpu']});const page=await browser.newPage({viewport:{width:1600,height:1100}});page.setDefaultTimeout(20000);
let mode='valid',release=null,delay=false;const question='検証装置の登録状態は？';let executes=0;
page.on('pageerror',e=>report.errors.push(e.message));
await page.route('**/api/**',async route=>{
const req=route.request(),path=new URL(req.url()).pathname;let body={};try{body=req.postDataJSON()||{};}catch{}
if(req.method()==='GET')return route.continue();
if(path==='/api/agent'){
if(body.read_selection){if(body.read_selection.operation==='EXECUTE')executes++;return route.continue();}
if(['関係分析 ','文書検索：','登録入力で比較 '].some(p=>body.message?.startsWith(p)))return route.continue();
fs.writeFileSync('/repo/.git/verification/pr276/h7-live/mode.json',JSON.stringify({mode}));
const response=await page.request.post('http://127.0.0.1:8126/agent',{data:body,headers:{Authorization:'Bearer owner-token'}});const value=await response.json();assert.equal(value.data.tool_results.length,0);assert.equal(value.data.answer_sections.facts.length,0);
if(delay)await new Promise(resolve=>{release=resolve;});
return route.fulfill({status:response.status(),contentType:'application/json',body:JSON.stringify(value)}).catch(()=>{});
}
if(['/api/session/login','/api/session/logout','/api/incidents/investigate','/api/decisions/compare','/api/economic-inputs/search','/api/capacity-inputs/search','/api/safety-inputs/search','/api/maintenance-inputs/search'].includes(path))return route.continue();
report.blocked.push(path);return route.abort();
});
const pane=page.getByRole('region',{name:'登録情報を選んで調べる',exact:true});
async function send(){await page.getByLabel('関係や影響について質問する',{exact:true}).fill('');await page.getByLabel('関係や影響について質問する',{exact:true}).fill(question);await page.getByRole('button',{name:'送信',exact:true}).click();}
async function actualRead(){await pane.getByRole('button',{name:/画面の設備/}).click();const response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/agent'&&r.request().postDataJSON()?.read_selection?.operation==='EXECUTE');await pane.getByRole('button',{name:'この項目を調べる',exact:true}).click();assert.equal((await response).status(),200);await pane.getByRole('region',{name:'選択した照会の結果',exact:true}).waitFor();}
async function done(id){report.cases.push({id,pass:true});await page.screenshot({path:out+'/'+id+'.png',fullPage:true});fs.writeFileSync(out+'/report.json',JSON.stringify(report,null,2));console.log(id+' PASS');}
try{
await page.goto(process.env.LINESCOPE_BROWSER_URL);await page.getByLabel('Bearer token',{exact:true}).fill(process.env.LINESCOPE_BROWSER_TOKEN);await page.getByRole('button',{name:'接続する',exact:true}).click();await page.getByRole('button',{name:'設備を選ぶ',exact:true}).click();await page.getByLabel('設備名・コード',{exact:true}).fill('M-204');await page.getByRole('button',{name:'検索',exact:true}).click();await page.getByRole('button',{name:/第1加工機.*M-204/}).click();await page.getByRole('tab',{name:'質問する',exact:true}).click();
await send();await pane.getByRole('button',{name:'候補「登録状態」を選ぶ',exact:true}).waitFor();const before=executes;await pane.getByRole('button',{name:'候補「登録状態」を選ぶ',exact:true}).click();assert.equal(executes,before);await actualRead();await done('S1-confirmed-only');
mode='unsupported';await send();await pane.getByText('参照観点の候補はありません。全項目から選ぶか、該当する観点がないを選べます。',{exact:true}).waitFor();assert.equal(await pane.getByRole('option',{name:'該当する観点がない',exact:true}).count(),1);await done('S2-no-candidate');
mode='failure';await send();await pane.getByText('AIの候補を利用できません。全項目から手動で選べます。',{exact:true}).waitFor();await pane.getByLabel('調べる項目',{exact:true}).selectOption('registered_state');await actualRead();await done('S3-manual-fallback');
mode='valid';delay=true;await send();for(let i=0;i<100&&!release;i++)await page.waitForTimeout(20);assert.ok(release);await pane.getByLabel('調べる項目',{exact:true}).selectOption('__none__');const pending=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/agent'&&!r.request().postDataJSON()?.read_selection&&r.request().postDataJSON()?.message===question);release();await pending;await page.getByRole('button',{name:'送信',exact:true}).waitFor();assert.equal(await pane.getByLabel('調べる項目',{exact:true}).inputValue(),'__none__');assert.equal(await pane.getByRole('button',{name:'候補「登録状態」を選ぶ',exact:true}).count(),0);await done('S4-late-suggestion');
assert.equal(report.errors.length,0);assert.equal(report.blocked.length,0);report.verdict='PASS';
}catch(e){report.verdict='FAIL';report.failure=String(e.stack||e);await page.screenshot({path:out+'/failure.png',fullPage:true}).catch(()=>{});process.exitCode=1;}
finally{fs.writeFileSync(out+'/report.json',JSON.stringify(report,null,2));await browser.close();console.log(JSON.stringify(report));}
})();
