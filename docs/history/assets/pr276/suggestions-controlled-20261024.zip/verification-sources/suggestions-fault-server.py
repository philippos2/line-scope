import json
from dataclasses import replace
from pathlib import Path
from uuid import uuid4
import uvicorn
from interfaces.test_explicit_read_http import services_for
from interfaces.test_read_suggestions import Model
from agent.test_explicit_read import Reads, SECOND
from linescope.application.reads import ToolError
from linescope.execution import ExecutionContext
from linescope.interfaces import api

out=Path('/repo/.git/verification/pr276/h7-live')
out.mkdir(exist_ok=True)
class FaultReads(Reads):
 def run(self, actor, tool, arguments, **kwargs):
  mode=json.loads((out/'mode.json').read_text())['mode']
  if mode=='authorization':raise ToolError('AUTHORIZATION_DENIED','Controlled denial')
  if mode=='unavailable' and tool=='get_equipment_state':raise ToolError('DEPENDENCY_UNAVAILABLE','Controlled retrieval failure')
  result=super().run(actor,tool,arguments,**kwargs)
  if tool=='get_equipment_state':
   if mode=='identity':return replace(result,data={**result.data,'equipment_id':SECOND})
   if mode=='evidence':return replace(result,evidence={})
  return result
services=services_for(FaultReads())
class SwitchModel:
 def complete(self, messages, *, schemas, deadline):
  mode=json.loads((out/'mode.json').read_text())['mode']
  return Model(mode).complete(messages,schemas=schemas,deadline=deadline)
services.agent.read_agent.llm=SwitchModel()
owned=services.conversations.create(ExecutionContext('owner','manager',uuid4()),{'read_scope':{'kind':'READ_SCOPE'}})
(out/'owned-context.json').write_text(json.dumps({'context_id':owned}))
api.build_api_services=lambda *args,**kwargs:services
uvicorn.run(api.create_app(),host='127.0.0.1',port=8126,access_log=False,log_level='error')
